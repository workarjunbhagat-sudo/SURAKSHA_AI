from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def test_health_is_available():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_message_analysis_returns_explanation_and_disclaimer():
    response = client.post("/v1/analyze/message", json={
        "text": "URGENT: your bank account will be blocked. Share OTP and click http://fake.example/login",
        "language": "English"
    })
    assert response.status_code == 200
    body = response.json()
    assert 0 <= body["risk"] <= 100
    assert body["risk_band"] in {"lower", "moderate", "high"}
    assert "indicators" in body and "actions" in body
    assert body["raw_content_stored"] is False
    assert "real-world" in body["limitations"]


def test_whitespace_message_is_rejected():
    response = client.post("/v1/analyze/message", json={"text": "   "})
    assert response.status_code == 422


def test_url_analysis_does_not_need_to_fetch_target():
    response = client.post("/v1/analyze/url", json={"url": "http://127.0.0.1:9/login?verify=1"})
    assert response.status_code == 200
    body = response.json()
    assert 0 <= body["risk"] <= 100
    assert "does not visit the URL" in body["limitations"]


def test_incident_response_is_multilingual():
    response = client.post("/v1/incident-response", json={"scenario": "shared_otp", "language": "Hindi"})
    assert response.status_code == 200
    body = response.json()
    assert len(body["steps"]) >= 3
    assert "ओटीपी" in " ".join(body["steps"])


def test_opt_in_history_stores_metadata_only(monkeypatch, tmp_path):
    monkeypatch.setenv("SURAKSHA_DB_PATH", str(tmp_path / "events.sqlite3"))
    secret_like_text = "A unique message with my private number 9988776655"
    response = client.post("/v1/analyze/message", json={
        "text": secret_like_text,
        "language": "English",
        "save_metadata": True,
    })
    assert response.status_code == 200
    assert "event_id" in response.json()
    events = client.get("/v1/history").json()["events"]
    assert len(events) == 1
    assert secret_like_text not in str(events)
    assert "9988776655" not in str(events)


def test_api_key_is_enforced_when_configured(monkeypatch):
    monkeypatch.setenv("SURAKSHA_API_KEY", "unit-test-secret")
    denied = client.post("/v1/analyze/message", json={"text": "hello"})
    allowed = client.post("/v1/analyze/message", json={"text": "hello"}, headers={"X-API-Key": "unit-test-secret"})
    assert denied.status_code == 401
    assert allowed.status_code == 200
