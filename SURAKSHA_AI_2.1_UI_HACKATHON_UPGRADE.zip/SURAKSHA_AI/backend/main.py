"""SURAKSHA AI REST API.

Run locally with: uvicorn backend.main:app --reload --port 8000
Set SURAKSHA_API_KEY to protect all /v1 endpoints. /health remains public.
"""
from __future__ import annotations

import hmac
import os
import time
import uuid
from typing import Literal

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from dotenv import load_dotenv
from pydantic import BaseModel, Field

from analyzer import analyze_message as run_message_analysis, analyze_url as run_url_analysis
from ml_engine import METRICS
from backend.storage import clear_events, list_events, record_event

load_dotenv()  # local .env support; never commit the real .env file

app = FastAPI(
    title="SURAKSHA AI API",
    description=(
        "A prototype API for explainable digital-scam risk assessment. "
        "It is a decision-support tool, not a guarantee that a message or URL is safe."
    ),
    version="2.0.0",
    contact={"name": "SURAKSHA AI Project Team"},
)

Language = Literal["English", "Hindi", "Hinglish"]


class MessageRequest(BaseModel):
    text: str = Field(min_length=1, max_length=15_000, description="Message text to assess; never send OTPs or passwords.")
    language: Language = "English"
    save_metadata: bool = Field(default=False, description="Opt-in: save aggregate event metadata only, never raw content.")


class URLRequest(BaseModel):
    url: str = Field(min_length=1, max_length=2_048)
    language: Language = "English"
    save_metadata: bool = False


class IncidentRequest(BaseModel):
    scenario: Literal[
        "clicked_link", "shared_otp", "transferred_money",
        "installed_remote_access", "shared_password", "shared_personal_data"
    ]
    language: Language = "English"


class ClearHistoryResponse(BaseModel):
    deleted_events: int


MESSAGES = {
    "clicked_link": {
        "English": ["Stop interacting with the page; do not enter more information or approve prompts.", "If you downloaded a file or app, do not open it; run a security scan using trusted security software.", "If you entered credentials, change them from a trusted device and enable multi-factor authentication where available.", "Monitor affected accounts and contact the relevant provider through its official app or website if anything looks unusual."],
        "Hindi": ["पेज से आगे बातचीत बंद करें; कोई और जानकारी न भरें और किसी अनुरोध को मंजूरी न दें।", "यदि कोई फ़ाइल या ऐप डाउनलोड हुआ है, तो उसे न खोलें; भरोसेमंद सुरक्षा सॉफ़्टवेयर से जाँच करें।", "यदि आपने लॉगिन जानकारी भरी है, तो भरोसेमंद डिवाइस से उसे बदलें और जहाँ उपलब्ध हो बहु-कारक प्रमाणीकरण चालू करें।", "संबंधित खातों पर नज़र रखें और संदिग्ध गतिविधि दिखे तो आधिकारिक ऐप या वेबसाइट से संपर्क करें।"],
        "Hinglish": ["Page par interaction stop karo; aur information enter mat karo aur prompts approve mat karo.", "Agar file ya app download hua hai, use open mat karo; trusted security software se scan karo.", "Agar credentials enter kiye, trusted device se change karo aur available ho to multi-factor authentication on karo.", "Affected accounts monitor karo; unusual activity ho to official app ya website se provider ko contact karo."]
    },
    "shared_otp": {
        "English": ["Contact your bank or service provider immediately using its official app, website, or a verified number.", "Ask the provider to secure the account and block or pause affected payment instruments if needed.", "Review recent transactions and preserve messages, timestamps, and transaction references.", "Change exposed credentials from a trusted device; never share another OTP with the caller."],
        "Hindi": ["अपने बैंक या सेवा प्रदाता से तुरंत उसके आधिकारिक ऐप, वेबसाइट या सत्यापित नंबर के माध्यम से संपर्क करें।", "प्रदाता से खाते को सुरक्षित करने और ज़रूरत पड़ने पर प्रभावित भुगतान माध्यम रोकने को कहें।", "हाल के लेन-देन देखें और संदेश, समय तथा लेन-देन संदर्भ सुरक्षित रखें।", "भरोसेमंद डिवाइस से उजागर लॉगिन जानकारी बदलें; कॉल करने वाले को कोई और ओटीपी न दें।"],
        "Hinglish": ["Bank ya service provider ko turant official app, website ya verified number se contact karo.", "Provider se account secure karne aur zarurat par affected payment method block/pause karne ko bolo.", "Recent transactions check karo aur messages, timestamps aur transaction references save rakho.", "Trusted device se exposed credentials change karo; caller ko koi aur OTP mat do."]
    },
    "transferred_money": {
        "English": ["Contact your bank or payment provider immediately and ask whether the transaction can be stopped or traced; recovery is not guaranteed.", "Save the transaction ID, recipient details, messages, call logs, and screenshots.", "Report the incident through the appropriate official cybercrime or law-enforcement channel in your location.", "Do not pay anyone who promises guaranteed recovery for an upfront fee."],
        "Hindi": ["अपने बैंक या भुगतान प्रदाता से तुरंत संपर्क करें और पूछें कि लेन-देन रोका या ट्रेस किया जा सकता है या नहीं; पैसे वापस मिलने की गारंटी नहीं है।", "लेन-देन आईडी, प्राप्तकर्ता विवरण, संदेश, कॉल लॉग और स्क्रीनशॉट सुरक्षित रखें।", "अपने क्षेत्र के उचित आधिकारिक साइबर अपराध या कानून प्रवर्तन माध्यम से घटना रिपोर्ट करें।", "पैसे वापस दिलाने की गारंटी देकर पहले शुल्क मांगने वालों को भुगतान न करें।"],
        "Hinglish": ["Bank ya payment provider ko turant contact karo aur poochho transaction stop/trace ho sakta hai ya nahi; recovery guaranteed nahi hai.", "Transaction ID, receiver details, messages, call logs aur screenshots save karo.", "Apne area ke appropriate official cybercrime ya law-enforcement channel par report karo.", "Jo pehle fee lekar guaranteed recovery ka promise kare, use paise mat do."]
    },
    "installed_remote_access": {
        "English": ["End the remote-access session and disconnect the device from the internet if you suspect ongoing control.", "From a different trusted device, contact your bank if banking or payment apps were accessible.", "Change exposed credentials and review account sessions, payment activity, and security settings.", "Get help from a trusted technician or official service provider before using the affected device for sensitive tasks."],
        "Hindi": ["रिमोट-एक्सेस सत्र बंद करें; यदि डिवाइस पर किसी और का नियंत्रण होने का शक है तो इंटरनेट से डिस्कनेक्ट करें।", "यदि बैंकिंग या भुगतान ऐप उपलब्ध थे, तो किसी दूसरे भरोसेमंद डिवाइस से बैंक से संपर्क करें।", "उजागर लॉगिन जानकारी बदलें और खाते के सत्र, भुगतान गतिविधि तथा सुरक्षा सेटिंग देखें।", "संवेदनशील काम के लिए डिवाइस इस्तेमाल करने से पहले भरोसेमंद तकनीशियन या आधिकारिक सेवा प्रदाता की मदद लें।"],
        "Hinglish": ["Remote-access session end karo; ongoing control ka doubt ho to device ko internet se disconnect karo.", "Agar banking ya payment apps accessible the, kisi doosre trusted device se bank ko contact karo.", "Exposed credentials change karo aur account sessions, payment activity aur security settings review karo.", "Sensitive tasks ke liye device use karne se pehle trusted technician ya official provider ki help lo."]
    },
    "shared_password": {
        "English": ["Change the password immediately from a trusted device, starting with the affected account.", "If you reused that password elsewhere, change it on those accounts too; use unique passwords.", "Sign out other sessions and enable multi-factor authentication where available.", "Check recovery email, phone number, and recent account activity for changes you did not make."],
        "Hindi": ["भरोसेमंद डिवाइस से तुरंत पासवर्ड बदलें और प्रभावित खाते से शुरुआत करें।", "यदि वही पासवर्ड अन्य जगह भी इस्तेमाल किया है, तो वहाँ भी बदलें; हर खाते के लिए अलग पासवर्ड रखें।", "अन्य सत्रों से साइन आउट करें और जहाँ उपलब्ध हो बहु-कारक प्रमाणीकरण चालू करें।", "रिकवरी ईमेल, फोन नंबर और हाल की खाता गतिविधि में अनजान बदलाव देखें।"],
        "Hinglish": ["Trusted device se turant password change karo, sabse pehle affected account ka.", "Agar same password aur jagah use kiya hai, wahan bhi change karo; har account ka unique password rakho.", "Other sessions sign out karo aur available ho to multi-factor authentication on karo.", "Recovery email, phone number aur recent account activity mein unknown changes check karo."]
    },
    "shared_personal_data": {
        "English": ["Do not send additional documents, codes, or financial details to the contact.", "If financial credentials were included, contact the relevant bank or service provider through official channels.", "Watch for account-reset attempts, impersonation, and follow-up calls or messages.", "Keep evidence and report suspected identity misuse to the appropriate official authority in your location."],
        "Hindi": ["उस संपर्क को और दस्तावेज़, कोड या वित्तीय जानकारी न भेजें।", "यदि वित्तीय लॉगिन जानकारी साझा हुई है, तो आधिकारिक माध्यम से संबंधित बैंक या सेवा प्रदाता से संपर्क करें।", "खाता रीसेट करने के प्रयास, पहचान की नकल और आगे आने वाली कॉल या संदेशों पर नज़र रखें।", "सबूत सुरक्षित रखें और पहचान के दुरुपयोग की आशंका अपने क्षेत्र के उचित आधिकारिक प्राधिकरण को रिपोर्ट करें।"],
        "Hinglish": ["Us contact ko aur documents, codes ya financial details mat bhejo.", "Agar financial credentials share hue, official channel se related bank ya provider ko contact karo.", "Account reset attempts, impersonation aur follow-up calls/messages par nazar rakho.", "Evidence save karo aur suspected identity misuse ko apne area ke appropriate official authority ko report karo."]
    },
}


def _authorize(x_api_key: str | None = Header(default=None, alias="X-API-Key")) -> None:
    expected = os.getenv("SURAKSHA_API_KEY", "").strip()
    if expected and (not x_api_key or not hmac.compare_digest(x_api_key, expected)):
        raise HTTPException(status_code=401, detail="Missing or invalid API key")


def _normalize_request_text(text: str) -> str:
    cleaned = text.strip()
    if not cleaned:
        raise HTTPException(status_code=422, detail="Text must not be empty or whitespace only")
    return cleaned


def _risk_band(risk: int) -> str:
    return "high" if risk >= 70 else "moderate" if risk >= 40 else "lower"


@app.get("/health", tags=["Operations"])
def health() -> dict:
    return {"status": "ok", "service": "suraksha-ai-api", "version": app.version, "auth_required_for_v1": bool(os.getenv("SURAKSHA_API_KEY", "").strip())}


@app.post("/v1/analyze/message", tags=["Analysis"], dependencies=[Depends(_authorize)])
def analyze_message(request: MessageRequest) -> dict:
    text = _normalize_request_text(request.text)
    started = time.perf_counter()
    try:
        result = run_message_analysis(text)
    except Exception as exc:  # keep internal exception details out of API responses
        raise HTTPException(status_code=503, detail="Analysis service temporarily unavailable") from exc
    latency_ms = round((time.perf_counter() - started) * 1000, 2)
    result.update({
        "risk_band": _risk_band(int(result.get("risk", 0))),
        "language": request.language,
        "request_id": str(uuid.uuid4()),
        "latency_ms": latency_ms,
        "limitations": "Prototype decision-support only. Metrics and predictions are not evidence of real-world fraud-detection performance or proof of fraud/safety; verify independently.",
        "raw_content_stored": False,
    })
    if request.save_metadata:
        result["event_id"] = record_event(
            source="message", risk=int(result.get("risk", 0)),
            category=str(result.get("category", "Unknown")), language=request.language,
            model=str(result.get("model", "unknown")),
        )
    return result


@app.post("/v1/analyze/url", tags=["Analysis"], dependencies=[Depends(_authorize)])
def analyze_url(request: URLRequest) -> dict:
    url = _normalize_request_text(request.url)
    # Deliberately analyze the URL string only. This endpoint never fetches or follows it.
    try:
        result = run_url_analysis(url)
    except Exception as exc:
        raise HTTPException(status_code=422, detail="The URL could not be analyzed") from exc
    risk = int(result.get("risk", 0))
    response = {
        **result,
        "risk_band": _risk_band(risk),
        "language": request.language,
        "request_id": str(uuid.uuid4()),
        "raw_content_stored": False,
        "limitations": "URL structure alone cannot establish whether a site is malicious or safe. The API does not visit the URL.",
    }
    if request.save_metadata:
        response["event_id"] = record_event(
            source="url", risk=risk, category="URL analysis", language=request.language,
            model="heuristic URL checks",
        )
    return response


@app.post("/v1/incident-response", tags=["Safety"], dependencies=[Depends(_authorize)])
def incident_response(request: IncidentRequest) -> dict:
    return {
        "scenario": request.scenario,
        "language": request.language,
        "priority": "urgent" if request.scenario in {"shared_otp", "transferred_money", "installed_remote_access"} else "high",
        "steps": MESSAGES[request.scenario][request.language],
        "disclaimer": {
            "English": "General safety guidance only. Contact your bank/service provider or local authorities through independently verified official channels.",
            "Hindi": "यह सामान्य सुरक्षा मार्गदर्शन है। बैंक/सेवा प्रदाता या स्थानीय अधिकारियों से स्वतंत्र रूप से सत्यापित आधिकारिक माध्यम से संपर्क करें।",
            "Hinglish": "Ye general safety guidance hai. Bank/provider ya local authorities ko independently verified official channel se contact karo."
        }[request.language]
    }


@app.get("/v1/model/metrics", tags=["Model"], dependencies=[Depends(_authorize)])
def model_metrics() -> dict:
    return {
        "metrics": {key: METRICS[key] for key in ("accuracy", "precision", "recall", "f1", "train_samples", "test_samples", "confusion_matrix")},
        "model": "TF-IDF + Logistic Regression",
        "evaluation_scope": "small curated educational demo dataset",
        "warning": "Do not interpret these metrics as real-world fraud-detection performance. Test with larger, independently collected and diverse data before any deployment decision.",
    }


@app.get("/v1/history", tags=["Privacy"], dependencies=[Depends(_authorize)])
def history(limit: int = Query(default=50, ge=1, le=200)) -> dict:
    return {"events": list_events(limit), "retention": "metadata only; raw content is not stored"}


@app.delete("/v1/history", tags=["Privacy"], dependencies=[Depends(_authorize)])
def delete_history() -> ClearHistoryResponse:
    return ClearHistoryResponse(deleted_events=clear_events())
