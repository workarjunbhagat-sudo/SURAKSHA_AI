"""Privacy-preserving SQLite event log.

By design, this module never stores raw message text, screenshots, URLs, OTPs,
passwords, or other user-provided content. Only opt-in analysis metadata is kept.
"""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any


def _db_path() -> Path:
    configured = os.getenv("SURAKSHA_DB_PATH", "data/suraksha_events.sqlite3")
    path = Path(configured).expanduser()
    if not path.is_absolute():
        path = Path(__file__).resolve().parent.parent / path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(), timeout=5)
    conn.row_factory = sqlite3.Row
    return conn


def initialize() -> None:
    with _connect() as conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS analysis_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                source TEXT NOT NULL,
                risk INTEGER NOT NULL,
                category TEXT NOT NULL,
                language TEXT NOT NULL,
                model TEXT NOT NULL
            )"""
        )


def record_event(*, source: str, risk: int, category: str, language: str, model: str) -> int:
    initialize()
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO analysis_events(source, risk, category, language, model) VALUES (?, ?, ?, ?, ?)",
            (source, int(risk), category[:120], language, model[:120]),
        )
        return int(cursor.lastrowid)


def list_events(limit: int = 50) -> list[dict[str, Any]]:
    initialize()
    limit = max(1, min(int(limit), 200))
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, created_at, source, risk, category, language, model "
            "FROM analysis_events ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(row) for row in rows]


def clear_events() -> int:
    initialize()
    with _connect() as conn:
        cursor = conn.execute("DELETE FROM analysis_events")
        return int(cursor.rowcount)
