"""Compare text-classification baselines with stratified 5-fold cross-validation.

Run from project root: python scripts/evaluate_models.py
The labels are a small, curated educational dataset. Results are exploratory and
must not be represented as real-world fraud-detection performance.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import time

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import make_scorer, precision_score, recall_score, f1_score
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ml_engine import SCAM_TEXTS, SAFE_TEXTS  # noqa: E402


def main() -> None:
    texts = list(SCAM_TEXTS) + list(SAFE_TEXTS)
    labels = [1] * len(SCAM_TEXTS) + [0] * len(SAFE_TEXTS)
    unique_count = len({" ".join(t.lower().split()) for t in texts})
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    models = {
        "TF-IDF + Logistic Regression": LogisticRegression(max_iter=1500, class_weight="balanced"),
        "TF-IDF + Linear SVM": LinearSVC(class_weight="balanced", random_state=42),
        "TF-IDF + Multinomial NB": MultinomialNB(),
    }
    scoring = {
        "accuracy": "accuracy",
        "precision": make_scorer(precision_score, zero_division=0),
        "recall": make_scorer(recall_score, zero_division=0),
        "f1": make_scorer(f1_score, zero_division=0),
    }
    output = {
        "dataset": {
            "samples": len(texts), "scam_samples": len(SCAM_TEXTS), "lower_risk_samples": len(SAFE_TEXTS),
            "unique_normalized_messages": unique_count,
            "evaluation": "stratified 5-fold cross-validation",
            "limitations": [
                "Small curated educational dataset, not a representative real-world dataset.",
                "Cross-validation reduces dependence on one split but does not remove template or source bias.",
                "Do not use these scores as evidence of production fraud-detection accuracy."
            ]
        },
        "models": {}
    }
    for name, classifier in models.items():
        pipeline = Pipeline([
            ("tfidf", TfidfVectorizer(lowercase=True, ngram_range=(1, 2), sublinear_tf=True, max_features=10000)),
            ("classifier", classifier),
        ])
        start = time.perf_counter()
        result = cross_validate(pipeline, texts, labels, cv=cv, scoring=scoring, n_jobs=1, return_train_score=False)
        elapsed = time.perf_counter() - start
        output["models"][name] = {
            metric: {"mean": round(float(result[f"test_{metric}"].mean()), 4), "std": round(float(result[f"test_{metric}"].std()), 4)}
            for metric in scoring
        }
        output["models"][name]["mean_fit_time_seconds"] = round(float(result["fit_time"].mean()), 4)
        output["models"][name]["wall_time_seconds"] = round(elapsed, 3)
        print(f"\n{name}")
        for metric in scoring:
            vals = result[f"test_{metric}"]
            print(f"  {metric:10s}: {vals.mean():.3f} ± {vals.std():.3f}")
        print(f"  mean fit  : {result['fit_time'].mean():.4f}s")
    out_path = ROOT / "docs" / "model_benchmark.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(f"\nSaved results to {out_path.relative_to(ROOT)}")
    print("Reminder: scores are exploratory for this curated dataset, not real-world efficacy claims.")


if __name__ == "__main__":
    main()
